README - Henry F. Walling Milwaukee Map, 1858

DESCRIPTION
Polygon shapefiles of political wards, blocks, water bodies, railroad lines, land areas (i.e., east side, west side, south side), and municipal boundary in the city of Milwaukee in 1858.  The original raster TIFF file was sourced from Harvard University and georeferenced in ArcMap.  This database makes available only a partial digitization of the map.

COORDINATE SYSTEM
NAD 1983 HARN State Plane Wisconsin South FIPS (4803 Feet)

DATA SOURCE(S)
Walling, Henry F. “Map of the County of Milwaukee, Wisconsin.” Published by M.H. Tyler, 1858.  Available via Harvard Map Collection at Harvard University.

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.