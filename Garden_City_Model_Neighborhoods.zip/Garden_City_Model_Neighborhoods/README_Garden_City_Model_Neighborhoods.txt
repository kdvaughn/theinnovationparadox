README - Garden City Model Neighborhoods

DESCRIPTION
Polygon shapefiles of parcels, parks, and structures of Milwaukee County's three Garden City model neighborhoods: Washington Highlands, Garden Homes, and Greendale.  The shapefiles depict the three neighborhoods in as-built condition when they were completed between the 1920s and 1940s.

COORDINATE SYSTEM
Geographic Coordinate System - GCS_WGS_1984
**Note: The majority of databases available on this open data portal utilize a HARN State Plane coordinate system.  This database utilizes a separate system because the data was extracted directly from the Milwaukee Master Property File (MPROP).

DATA SOURCE(S)
City of Milwaukee, Master Property File (MPROP)
Department of the Interior, National Park Service Historic District Filings: Washington Highlands (1989), Garden Homes (1990), Greendale (2005)

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.