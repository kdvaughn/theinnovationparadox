README - Urban Renewal & Expressway Development, 1946-1969

DESCRIPTION
Digitization of geographies related to expressway development, urban renewal plan areas, and other relevant economic districts in Milwaukee from 1946-1969.  The files include individual locations (points) and planning boundaries (polygons).

COORDINATE SYSTEM
Geographic Coordinate System - NAD 1983 HARN State Plane Wisconsin South FIPS 4803 (US Feet)

DATA SOURCE(S)
Candeub & Fleissig. “General Neighborhood Renewal Plan: East Side Neighborhood Renewal Area, City of Milwaukee, Wisconsin.” 1961.

City of Milwaukee Department of City Development. “Summary of Halyard Park Redevelopment Project.” 1967.

City of Milwaukee Division of Economic Development. “Boys’ Tech Industrial Renewal.” 1967.

Gurda, Leon M. “Hillside Neighborhood Redevelopment Project No. 1.” City of Milwaukee Office of Inspector of Buildings, 9 Oct 1953.

Hisaka, Don M. “Proposal for the Development of Plymouth Hill, Hillside Neighborhood Redevelopment Project UR-WIS 1-2.” Prepared for the City of Milwaukee Redevelopment Authority. 1962.

Howard Needles Tamen & Bergendoff. “Milwaukee Civic Center Plaza Development and Underground Parking Garage.” 1959.

John Steele Appraisal Company. “Re-Use Appraisal Hay Market Square Redevelopment Project.” Prepared for the Redevelopment Authority of the City of Milwaukee. 1966.

League of Women Voters. “Housing in Milwaukee: A Study of Public and Private Housing and Programs for the Future.” 1968.

Midwest Planning and Research, Inc. “Milwaukee Depot Area Study: Land Utilization and Marketability Analysis.” Prepared for the City of Milwaukee Department of City Development. 1967.

O’Reilly, Charles T., et al., “The People of the Inner Core-North: A Study of Milwaukee’s Negro Community.” LePlay Research, Inc.: New York, 1965.

Ratcliff, Richard U. “Re-Use Value and Marketability Analysis: UR Wis. 1-1 Lower Third Ward Redevelopment Project, Milwaukee.” 1959.

Real Estate Research Corporation. “Land Utilization and Marketability Study Kilbourntown Number 3 Urban Renewal Project, Milwaukee Wisconsin.” Prepared for the Redevelopment Authority of the City of Milwaukee. 1965.

Redevelopment Authority of the City of Milwaukee. “Redevelopment Plan Hillside Neighborhood Redevelopment Project UR WIS 1-2.” 1961.

Redevelopment Authority of the City of Milwaukee. “Redevelopment Plan Wisconsin R-20 Marquette Urban Renewal Area (R 213).” 1 April 1964.

State Highway Commission of Wisconsin. “1944-1945 Origin-Destination Traffic Survey for the Milwaukee Metropolitan Area.” Prepared in cooperation with U.S. Public Roads Administration. 1946.

Stefaniak, Norbert J. “WAICO Triangle Land Use and Marketability Study.” Prepared for the Redevelopment Authority of the City of Milwaukee. 1969.

Talsky, Leo C. “Real Estate, Race, and Revenue: A Milwaukee Case Study.” 1967. University of Wisconsin-Milwaukee, Master’s Thesis.

United States, Senate, Committee on Finance. “Tax Incentives to Encourage Housing in Urban Poverty Areas, Hearings on S. 3100: A Bill to Encourage and Assist Private Enterprise to Provide Adequate Housing in Urban Poverty Areas for Low-Income and Lower Middle Persons, Testimony of Elmer Winter.” U.S. Government Printing Office (1967), pp. 337-341.

Walter R. Kuehnle & Company. “Land Utilization and Marketability Study Midtown Conservation Project , Milwaukee, Wisconsin, WIS. R-24.” Prepared for the Redevelopment Authority of the City of Milwaukee. 1966.

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.