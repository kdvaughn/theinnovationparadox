README - Ethnic & Racial Enclaves, Milwaukee, 1910-1930

DESCRIPTION
Digitization of the boundaries of ethnic and racial enclaves in Milwaukee from 1910-1930.  Digitization of points of interest for relevant socio-cultural epicenters of the enclaves for the same time period.

COORDINATE SYSTEM
Geographic Coordinate System - NAD 1983 HARN State Plane Wisconsin South FIPS 4803 (US Feet)

DATA SOURCE(S)
Various data sources provided exact boundaries or general descriptions of features that were used to digitize the points and polygons.  The exact data sources are identified in the attributes table of each shapefile.
Please refer to the "References" chapter available as a PDF on the main branch of the GitHub repository to find the full citation for each source.

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.