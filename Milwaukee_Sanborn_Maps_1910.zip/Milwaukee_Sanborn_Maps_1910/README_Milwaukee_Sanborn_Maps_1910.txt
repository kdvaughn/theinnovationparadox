README - Milwaukee Sanborn Maps, 1910

DESCRIPTION
Digitization of features from the Sanborn Maps of Milwaukee (1910).  Features include waterways, land masses, blocks, streets, and structures.  Note that this dataset is a partial digitization of the Sanborn Maps.  As additional features are digitized, the database will be updated.
To understand data fields in the structures shapefile, please consult "Appendix A. CIM Technical Documentation" on the main branch of the GitHub repository.  The data dictionary for the structures shapefile can be found in this PDF.

COORDINATE SYSTEM
Geographic Coordinate System - NAD 1983 HARN State Plane Wisconsin South FIPS 4803 (US Feet)

DATA SOURCE(S)
Sanborn Map Company. "Sanborn Maps of Milwaukee." 1910.
The Sanborn Maps of Milwaukee are available as map services from the Milwaukee County Land Information Office (MCLIO): https://lio.milwaukeecountywi.gov/arcgis/rest/services/Historical/Sanborn1910_Cached/MapServer

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.