README - Milwaukee Housing Survey, 1936

DESCRIPTION
Digitization of three maps from the Milwaukee Housing Survey (1936).  Map features include blight areas, transportation facilities, and tax delinquent properties.

COORDINATE SYSTEM
Geographic Coordinate System - NAD 1983 HARN State Plane Wisconsin South FIPS 4803 (US Feet)

DATA SOURCE(S)
Milwaukee Board of Public Land Commissioners. "City of Milwaukee Housing Survey." Overseen by Charles Bennett, 1936.
Map collection available via UW-Milwaukee's American Geographical Society Library (AGSL): https://collections.lib.uwm.edu/digital/collection/agdm/id/25564/rec/142

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.