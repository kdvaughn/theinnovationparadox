README - Evolution of Black Milwaukee, 1852-1970

DESCRIPTION
Digitization of various geographies (points, polygons) that identify the spatial evolution of Black Milwaukee from 1852-1970.  Spatial geographies include individual addresses/locations, economic districts, and neighborhood boundaries.

COORDINATE SYSTEM
Geographic Coordinate System - NAD 1983 HARN State Plane Wisconsin South FIPS 4803 (US Feet)

DATA SOURCE(S)
Buchanan, Thomas R. Black Milwaukee 1890-1915. 1974. University of Wisconsin-Milwaukee, Master’s Thesis.

Citizens’ Governmental Research Bureau. “Milwaukee’s Negro Community.” 1946. Edited by Paula Lynagh.

City of Milwaukee. “Central Business District Historic Resources Survey.” City of Milwaukee Department of City Development, 1986.

Geenen, Paul. Images of America: Milwaukee’s Bronzeville 1900-1950. Arcadia Publishing: San Francisco, 2006.

Grover, Michael Ross. “All Things to Black Folks: A History of the Milwaukee Urban League, 1919-1980.” 1994. University of Wisconsin-Milwaukee, PhD Dissertation.

Imse, Thomas P. “The Negro Community in Milwaukee.” 1942. Marquette University, Master’s Thesis.

Milwaukee Housing Commission. “Report of the Mayor’s Housing Commission, Milwaukee, Wisconsin.” Directed by Edmond H. Hoben. City of Milwaukee, 1933.

Milwaukee Redevelopment Coordinating Committee. “Blight Elimination & Urban Redevelopment in Milwaukee.” City of Milwaukee, 1948.

O’Reilly, Charles T., et al., “The People of the Inner Core-North: A Study of Milwaukee’s Negro Community.” LePlay Research, Inc.: New York, 1965.

Schmitz, Keith R. Milwaukee and its Black Community: 1930-1942. 1979. University of Wisconsin-Milwaukee, Master’s Thesis.

Talsky, Leo C. “Real Estate, Race, and Revenue: A Milwaukee Case Study.” 1967. University of Wisconsin-Milwaukee, Master’s Thesis.

Vick, William A. “From Walnut Street to No Street: Milwaukee’s Afro-American Businesses, 1945-1967.” 1993. University of Wisconsin-Milwaukee, Master’s Thesis.

Vollmar, William J. “The Negro in a Midwest Frontier City, Milwaukee: 1835-1870.” 1968. Marquette University, Master’s Thesis.

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.