README - Caspar Milwaukee Map, 1912

DESCRIPTION
Polygon shapefiles of political wards, streetcar lines, and railroad lines in the city of Milwaukee in 1912.  The original raster TIFF file was sourced from Harvard University and georeferenced in ArcMap.

COORDINATE SYSTEM
NAD 1983 HARN State Plane Wisconsin South FIPS (4803 Feet)

DATA SOURCE(S)
C.N. Caspar Company. “Map of the City of Milwaukee.” Published by C.N. Caspar Co. Publishers, 1912.  Available via Harvard Map Collection at Harvard University.

AFFILIATION & PURPOSE
This data is made available within the open data portal for my dissertation research. Making the data publicly available is an integral component of my research methodology that utilizes city information modeling (CIM) and digital twins. The online tools using this data can be found at www.theinnovationparadox.com.

This data is made available for educational purposes in partial fulfillment of doctoral research requirements at the University of Wisconsin-Milwaukee’s School of Architecture and Urban Planning.

DISCLAIMER
This research utilizes primary source documents, secondary historical research articles and books, and tabular data that accurately portrays conditions in Milwaukee’s history. These sources include terminology, phrases, and language that is offensive and derogatory. Though the language is inappropriate, it is reproduced in this research for the purposes of historical accuracy with accompanying footnotes and sources to provide the reader with needed context.

CONTACT
For technical issues or questions, please contact Kristian Vaughn at kdvaughn@uwm.edu.